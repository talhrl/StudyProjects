package coupon_project.beans;

/**
 * Enum class for coupon category
 */
public enum Category {
    Grocery,
    Electricity,
    Restaurant,
    Vacation,
    Fashion
}