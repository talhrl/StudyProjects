package coupon_project;

import coupon_project.tester.MainTester;

public class project {
    public static void main(String[] args) {
        MainTester.mainTest();
    }
}